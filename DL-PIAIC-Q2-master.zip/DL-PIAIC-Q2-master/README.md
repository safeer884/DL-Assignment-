#1 This assignment is consist of 5 mini assignments in which :

* 2 Assignments For Binary Classification
* 2 Assignment For Regression
* 1 Assignment For Multiclass Classification

Steps To Follow To Submit These Assignments :

1) Do all of the above assignments in different notebooks.
2) Put all the assignments in a single repository.
3) This time share your repository link and not your particular notebook link in assignment.
4) Fill the below form in order to submit your assignment : 

Form Link : https://docs.google.com/forms/d/e/1FAIpQLSeboGJkUDXk44-fMKpkaLkBXJWxSTTbC1FY10jATu5rqxj_wQ/viewform?usp=sf_link
